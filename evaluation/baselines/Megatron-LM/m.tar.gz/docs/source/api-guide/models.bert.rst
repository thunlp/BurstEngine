models.bert package
===================
Useful package for training bert and bert like encoder only models. It optionally comes with a binary head that can be used for classification tasks . 

Submodules
----------

models.bert.bert\_model module
------------------------------

.. automodule:: core.models.bert.bert_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: core.models.bert
   :members:
   :undoc-members:
   :show-inheritance:
