Mixture of Experts package
==========================

.. mdinclude :: ../../../megatron/core/transformer/moe/README.md
