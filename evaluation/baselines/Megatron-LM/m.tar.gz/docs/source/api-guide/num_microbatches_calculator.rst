Microbatches Calculator
==============
This api is used to calculate the number of microbatches required to fit a given model on a given batch size.


Module contents
---------------

.. automodule:: core.num_microbatches_calculator
   :members:
   :undoc-members:
   :show-inheritance:
