models.t5 package
=================

Submodules
----------

models.t5.t5\_model module
--------------------------

.. automodule:: core.models.T5.t5_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: core.models.T5
   :members:
   :undoc-members:
   :show-inheritance:
